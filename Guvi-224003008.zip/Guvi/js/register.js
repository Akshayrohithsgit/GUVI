// includes('../php');
$(document).ready(function() {
	$('#sub').submit(function(e) {
		e.preventDefault();
        var Name = $('#Name').val();
		var Password = $('#Password').val();
        var Email=$('#Email').val();
        var DOB=$('#DOB').val();
		var Phone=$('#Phone').val();
		$.ajax({
			url: 'http://localhost:3000/php/register.php',
			type: 'POST',
			dataType:"json",
			data:{
				Name: Name,
				Password: Password,
				Email:Email,
				DOB:DOB,
				Phone:Phone
			},
			success: function(response) {
                console.log(response);
				if(Object.keys(response.length)>1)
				{
					const val=response.uid;
					localStorage.setItem('uid',val);
					window.location.replace("http://127.0.0.1:5500/profile.html");
				}
				else
				{
					$('#Help').html("Email Already Exist");
				}
                // alert("success")

			},
			error: function(response)
			{
				alert("Something went wrong in front end");
			}

		});

	});
});
// register.js

$(document).ready(function () {
    $("#registerBtn").click(function () {
        // Get values from input fields
        var email = $("#Email").val();
        var name = $("#Name").val();
        var gender = $("input[name='gender']:checked").val();
        var age = $("#Age").val();
        var password = $("#Password").val();
        var confirmPassword = $("#ConfirmPassword").val();
        var dob = $("#DOB").val();

        // Perform validation, e.g., password match check
        if (password !== confirmPassword) {
            alert("Passwords do not match.");
            return;
        }

        // Perform AJAX request
        $.ajax({
            type: "POST",
            url: "your_registration_handler.php", // Replace with your actual backend endpoint
            data: {
                Email: email,
                Name: name,
                Gender: gender,
                Age: age,
                Password: password,
                DOB: dob
            },
            success: function (response) {
                // Handle the response from the server
                console.log(response);
                // Add your logic here
            },
            error: function (error) {
                console.log(error);
                // Handle errors
            }
        });
    });
});



